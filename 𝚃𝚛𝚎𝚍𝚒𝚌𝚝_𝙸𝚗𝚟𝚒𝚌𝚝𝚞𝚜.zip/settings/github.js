module.exports = {
  githubToken: "ghp_",
  githubUser: "NAMA_GITHUB"
};