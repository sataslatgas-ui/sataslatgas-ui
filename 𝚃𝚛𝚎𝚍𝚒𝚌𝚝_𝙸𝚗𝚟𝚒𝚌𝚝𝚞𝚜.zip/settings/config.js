module.exports = {
  tokenBot: "8743729681:AAENR5oC05prDZIJyx8D5vu17ZZ245phJ9E",
  ownerID: "5126860596",
  adminID: "5126860596",
};